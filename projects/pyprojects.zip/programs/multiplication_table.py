#table of any number
n = int(input("Input a number: "))
for i in range(1,11):
   print(n,'x',i,'=',n*i)
