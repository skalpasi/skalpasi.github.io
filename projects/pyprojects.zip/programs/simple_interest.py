#write a program to calculate simple interest.
def SI(p,r,t):
    si=p*r*t/100
    return si
p=int(input("enter principle amount"))
r=int(input("enter rate of interest"))
t=int(input("enter time in yrs"))
a=SI(p,r,t)
print("the simple interest is rupees",a)
