import math 
a = eval(input('Enter side 1: ')) 
b = eval(input('Enter side 2: ')) 
c = eval(input('Enter side 3: ')) 
perimeter = a + b + c 
s = perimeter / 2 
area = math.sqrt(s*(s - a) * (s - b) * (s - c)) 
print('Area of trieangle = ', area, 'cm\u00b2') 

 
