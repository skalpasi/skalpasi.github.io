#write a program to calculate sum of squares of n natural numbers where n is the number taken as input.
n=int(input("enter number upto which the sum of squares has to be calculated"))
s=0
for i in range(1,n+1):
    s=s+(i**2)
print("the sum of squares is",s)
