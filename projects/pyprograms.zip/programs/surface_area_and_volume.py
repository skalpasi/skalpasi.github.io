#write a program to calculate the surface area and volume of a sphere whose radius is taken as input from the user.
r=float(input("enter radius of the sphere"))
s=4*3.14*(r**2)
v=4/3*3.14*(r**3)
print("the surface area of the sphere is", s)
print("the volume of the sphere is", v)
