import math 

height = eval(input('Enter height: ')) 
base = eval(input('Enter base: ')) 

area = (1/2) * base * height

print('Area of trieangle = ', area, 'cm\u00b2') 

 
