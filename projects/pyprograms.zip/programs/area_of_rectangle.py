length = eval(input('Enter length of rectangle : ')) 
breadth = eval(input('Enter breadth of rectangle : ')) 

perimeter = (length + breadth) * 2 
area = length * breadth 

print('Perimeter = ', perimeter) 
print('Area = ', area) 

 
