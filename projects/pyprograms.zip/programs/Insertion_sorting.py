#insertion sorting
def sort():
    l=[72,43,4,34,54,54,42,65,12,4,61]
    print('Original List: ',l)
    for i in l:
        j=l.index(i)
        while j>0:
            if l[j-1]>l[j]:
                l[j-1],l[j]=l[j],l[j-1]
            else:
                break
            j-=1
    print('List after sorting: ',l)
sort()
