#write a program to calculate sum of digits of a number.
a=int(input("enter a number"))
b=0
while a>0:
    b=b+(a%10)
    a=a//10
print("the sum of digits is",b)
