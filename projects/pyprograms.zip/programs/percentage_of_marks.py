#write a program to calculate percentage of a student.
def percentage(z,x,v,h,n):
    global a
    a=(z+x+v+h+n)/500*100
    return a
m=int(input("enter marks in maths"))
p=int(input("enter marks in physics "))
c=int(input("enter marks in chemistry "))
e=int(input("enter marks in english "))
cs=int(input("enter marks in computer science "))
percentage(m,p,c,e,cs)
print("the percentage is",a)
