num1 = eval(input('Input firsst number : '))
num2 = eval(input('Input second number : '))
num3 = eval(input('Input third number : '))

if (num1 > num2) :
    if (num1 > num3) :
            print(num1, 'is greatest')

elif (num2 > num1) :
    if (num2 > num3) :
            print(num2, 'is greatest')

else :
    print(num3, 'is greatest')
