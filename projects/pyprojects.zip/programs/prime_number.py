#write a program to check whether the entered number is prime or not.
n1=int(input("enter the number"))
a=0
for i in range(2,n1):
    if n1%i==0:
        a=a+1
if a>0:
    print("the entered number is not prime")
else:
    print("the entered number is prime")
