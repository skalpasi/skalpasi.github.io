#creating string
#single quotes
string1 = 'Hello World \n'
print(string1)

#double quotes 
string2 = "My name is Sarthak \n"
print(string2) 
  
#triple quotes 
string3 = '''I'm a student of Class XI \n'''
print(string3) 

#multiple lines 
string4 ='''This 
is 
a
multi
line
string'''
print(string4)

#****************************************************

#string slicing

string5 = 'Hello World!'
#printing 3rd to 12th character 
print(string1[3:12]) 
  
#printing characters between 3rd and 2nd last character 
print(string1[3:-2])

#****************************************************

#deleting / updating strings

string6 = "Hello, I'm Sarthak"
string6 = "Welcome to the Geek World"   #updating string
print(string6) 
