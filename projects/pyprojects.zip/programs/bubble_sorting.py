#bubble sorting
def sort():
    l=[3,43,5,67,6,7,786,8,43,1,54]
    n=len(l)
    print('Original List: ',l)
    for i in range(n-1):
        for j in range(n-i-1):
            if l[j]>l[j+1]:
                l[j],l[j+1]=l[j+1],l[j]
    print('List after sorting: ',l)
   
sort()
