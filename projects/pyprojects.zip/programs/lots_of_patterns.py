#numerical pyramid
for i in range(10):
    print(str(i) * i)
print('\n')

#numerical pyramid 2
for i in range(10):
    for j in range(i+1):
        print(j, end=' ')
    print('')
print('\n')

#asteriks pyramid
for i in range(5):
    for j in range(i+1):
        print("* ",end="")
    print()
print('\n')

#asterisk pyramid 2
for i in range (7):
    for j in range(i+1):
        print('*', end=' ')
    print()
for i in range (7,0,-1):
    for j in range(i-1):
        print('*', end=' ')
    print()
print('\n')

#letter Z
z="";    
for i in range(7):    
    for j in range(7):     
        if (((i==0 or i==6) and j>=0 and j<=6) or i+j==6):  
            z=z+"*"    
        else:      
            z=z+" "    
    z=z+"\n"    
print(z);

#alphabetical triangle
y=65
for i in range(6):
    for j in range(i+1):
        x=chr(y)
        print(x,end=' ')
        y+=1
    print('')
print('\n')
