# Creating a List 
List = [] 
print("Intial blank List: ") 
print(List) 
  
# List with the use of a String 
List = ['ThisIsString'] 
print("\nList with the use of String: ") 
print(List) 
  
# List with the use of multiple values 
List = ["This", "is", "not","a","string"] 
print("\nList containing multiple values: ") 
print(List[0])  
print(List[2]) 
  
# 2-Dimensional List
List = [['2', 'D'] , ['List']] 
print("\nMulti-Dimensional List: ") 
print(List) 


# List with the use of Numbers 
List = [1, 2, 4, 4, 3, 3, 3, 6, 5] 
print("\nList with the use of Numbers: ") 
print(List) 
  
# List with mixed type of values  
List = [1, 2, 'string1', 4, 'string2', 6, 'string3'] 
print("\nList with the use of Mixed Values: ") 
print(List) 
  
# Addition of Elements  in the List 
List.append(1) 
List.append(2) 
List.append(4) 
print("\nList after Addition of Three elements: ") 
print(List) 
  
# Adding elements to the List using Iterator 
for i in range(1, 4): 
    List.append(i) 
print("\nList after Addition of elements from 1-3: ") 
print(List) 
  
# Adding Tuples to the List 
List.append((5, 6)) 
print("\nList after Addition of a Tuple: ") 
print(List) 
  
# Addition of List to a List 
List2 = ['Hello', 'World'] 
List.append(List2) 
print("\nList after Addition of a List: ") 
print(List) 
