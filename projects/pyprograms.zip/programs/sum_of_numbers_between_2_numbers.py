#write a program to calculate sum of odd and even numbers lying between two numbers taken as input.
a=int(input("enter lower number"))
b=int(input("enter higher number"))
j=0
k=0
for i in range(a+1,b):
    if i%2==0:
        j=j+i
    else:
        k=k+i
print("the sum of odd numbers between the numbers are", k)
print("the sum of even numbers between the numbers are", j)
