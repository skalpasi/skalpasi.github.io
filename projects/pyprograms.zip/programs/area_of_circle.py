radius = eval(input('Enter radius of circle : '))

area = (22/7) * radius * radius

print('Area of circle = ', area)
