sub1 = eval(input('Enter marks in first subject : '))
sub2 = eval(input('Enter marks in second subject : '))
sub3 = eval(input('Enter marks in third subject : '))
sub4 = eval(input('Enter marks in fourth subject : '))
sub5 = eval(input('Enter marks in fifth subject : '))

total = sub1 + sub2 + sub3 + sub4 + sub5

average = total/5

print('Total = ', total)
print('Average = ', average)
