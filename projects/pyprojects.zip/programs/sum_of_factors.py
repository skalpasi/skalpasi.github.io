#write a program to find out factors of a number and also find out the sum of those factors.
n=int(input("enter a number"))
a=0
for i in range (1,n+1):
    if n%i==0:
        print("the factors are",i)
        a=a+i
print("the sum of factors are",a)
