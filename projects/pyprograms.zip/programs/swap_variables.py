#write a program to exchange the value of 2 variables without the use of third variable.
x=int(input("enter value for variable x"))
y=int(input("enter value for variable y"))
x,y=y,x
print("x=",x)
print("y=",y)
